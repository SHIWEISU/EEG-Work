/*******************************************************************************
  * @file    GPIO/IOToggle/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.5.0
  * @date    08-April-2011
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and peripherals
  *          interrupt service routine.
  ******************************************************************************/
	
/* Includes ------------------------------------------------------------------*/	
#include "MCP4xx.h" 
#include "spi.h"
#include "delay.h"
//#include "usart.h"

void MCP4Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
  /*******************/
	RCC_APB2PeriphClockCmd(	RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB, ENABLE );	
 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  //�����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_7;  //,12-1�55-2.6-3,�SPI_NSS
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;  //�������
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_SetBits(GPIOA,GPIO_Pin_8| GPIO_Pin_7);
	GPIO_SetBits(GPIOB,GPIO_Pin_7);
}


/**
  * @brief  �����ֵ�λ��д����
  *          
  * @note   
  * @param  None
  * @retval None
  */
void WriteMCP4xx1(u8 data){
	
	u8 cmd = 0;
	MCP4_CS1=0;
	delay_ms(1);
//	cmd |=MCP_CMD_WRITE<<4;
//	cmd |=MCP_P0P1_SEL<<0;
	cmd =0x11;
	SPI2_ReadWriteByte(cmd);
	SPI2_ReadWriteByte(data);
	MCP4_CS1=1;
	
	MCP4_CS1=0;
	delay_ms(1);
//	cmd |=MCP_CMD_WRITE<<4;
//	cmd |=MCP_P0P1_SEL<<0;
	cmd =0x11;
	SPI2_ReadWriteByte(cmd);
	SPI2_ReadWriteByte(data);
	MCP4_CS1=1;
} 
void WriteMCP4xx2(u8 data){
	
	u8 cmd = 0;
	MCP4_CS2=0;
	delay_ms(1);
//	cmd |=MCP_CMD_WRITE<<4;
//	cmd |=MCP_P0P1_SEL<<0;
	cmd =0x11;
	SPI2_ReadWriteByte(cmd);
	SPI2_ReadWriteByte(data);
	MCP4_CS2=1;
	
	MCP4_CS2=0;
	delay_ms(1);
//	cmd |=MCP_CMD_WRITE<<4;
//	cmd |=MCP_P0P1_SEL<<0;
	cmd =0x11;
	SPI2_ReadWriteByte(cmd);
	SPI2_ReadWriteByte(data);
	MCP4_CS2=1;
} 
void WriteMCP4xx3(u8 data){
	
	u8 cmd = 0;
	MCP4_CS3=0;
	delay_ms(1);
//	cmd |=MCP_CMD_WRITE<<4;
//	cmd |=MCP_P0P1_SEL<<0;
	cmd =0x11;
	SPI2_ReadWriteByte(cmd);
	SPI2_ReadWriteByte(data);
	MCP4_CS3=1;
	
	MCP4_CS3=0;
	delay_ms(1);
//	cmd |=MCP_CMD_WRITE<<4;
//	cmd |=MCP_P0P1_SEL<<0;
	cmd =0x11;
	SPI2_ReadWriteByte(cmd);
	SPI2_ReadWriteByte(data);
	MCP4_CS3=1;
} 



















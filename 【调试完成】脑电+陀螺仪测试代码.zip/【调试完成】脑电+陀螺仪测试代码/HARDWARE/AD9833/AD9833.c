/**********************************************************
										 
���ܣ�stm32f103rct6���ƣ�25MHzʱ�ӣ� AD9833���Ҳ���Ƶ�������Χ0-10M(�ɱ༭0-100M)��
			������0-500K�����ǲ���0-1M��ɨƵĬ�����Ҳ� ��
**********************************************************/
#include "AD9833.h"		// AD9833 definitions.
#include "sys.h"
#include "delay.h"		// AD9833 definitions.
#include "spi.h"
#define FCLK 25000000	//���þ���Ƶ��

//PB12 98331��ʹ�ܽţ�PB5 ��Ӧ2��PB6��Ӧ3,7��Ӧ���ֵ�λ��
//#define RealFreDat    268435456.0/FCLK//�ܵĹ�ʽΪ Fout=��Fclk/2��28�η���*28λ�Ĵ�����ֵ
double RealFreDat = 268435456.0/FCLK;
/***************************************************************************//**
 * @brief Initializes the SPI communication peripheral and resets the part.
 *
 * @return 1.
*******************************************************************************/
unsigned char AD9833_Init(void)
{
    SPI2_Init();	
    //AD9833_SetRegisterValue(AD9833_REG_CMD | AD9833_RESET);
	AD9833_SetRegisterValue(0x0100); //
    return (1);
}

unsigned char AD9833_SPI_Write(unsigned char* data,
                        unsigned char bytesNumber)
{
	unsigned char i =0;
	unsigned char writeData[5]	= {0,0, 0, 0, 0};
	AD9833_FSYNC =0;
	for(i = 0;i < bytesNumber;i ++)
	{
		writeData[i] = data[i + 1];
	}
	for(i=0 ;i<bytesNumber ;i++) 
	{					 	
	//while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET); //���ָ����SPI��־λ�������:���ͻ���ձ�־λ
		SPI2_ReadWriteByte(writeData[i]);
	}
	AD9833_FSYNC = 1;
	delay_us(5);

	
	return i;
	
}

unsigned char AD9833_SPI_Write2(unsigned char* data,
                        unsigned char bytesNumber)
{
	unsigned char i =0;
	unsigned char writeData[5]	= {0,0, 0, 0, 0};
	AD9833_FSYNC2 =0;
	for(i = 0;i < bytesNumber;i ++)
	{
		writeData[i] = data[i + 1];
	}
	for(i=0 ;i<bytesNumber ;i++) 
	{					 	
	//while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET); //���ָ����SPI��־λ�������:���ͻ���ձ�־λ
		SPI2_ReadWriteByte(writeData[i]);
	}
	AD9833_FSYNC2 = 1;
	delay_us(5);

	
	return i;
	
}

unsigned char AD9833_SPI_Write3(unsigned char* data,
                        unsigned char bytesNumber)
{
	unsigned char i =0;
	unsigned char writeData[5]	= {0,0, 0, 0, 0};
	AD9833_FSYNC3 =0;
	for(i = 0;i < bytesNumber;i ++)
	{
		writeData[i] = data[i + 1];
	}
	for(i=0 ;i<bytesNumber ;i++) 
	{					 	
	//while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET); //���ָ����SPI��־λ�������:���ͻ���ձ�־λ
		SPI2_ReadWriteByte(writeData[i]);
	}
	AD9833_FSYNC3 = 1;
	delay_us(5);

	
	return i;
	
}


unsigned char AD9833_SPI_Write_all(unsigned char* data,
                        unsigned char bytesNumber)
{
	unsigned char i =0;
	unsigned char writeData[5]	= {0,0, 0, 0, 0};
//	AD9833_FSYNC3 =0;
	GPIO_ResetBits(GPIOB,GPIO_Pin_12| GPIO_Pin_5 | GPIO_Pin_6);
	for(i = 0;i < bytesNumber;i ++)
	{
		writeData[i] = data[i + 1];
	}
	for(i=0 ;i<bytesNumber ;i++) 
	{					 	
	//while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET); //���ָ����SPI��־λ�������:���ͻ���ձ�־λ
		SPI2_ReadWriteByte(writeData[i]);
	}
//	AD9833_FSYNC3 = 1;
	GPIO_SetBits(GPIOB,GPIO_Pin_12| GPIO_Pin_5 | GPIO_Pin_6);
	delay_us(5);

	
	return i;
	
}
/***************************************************************************//**
 * @brief Sets the Reset bit of the AD9833.
 *
 * @return None.
*******************************************************************************/
void AD9833_Reset(void)
{
    AD9833_SetRegisterValue_all(AD9833_REG_CMD | AD9833_RESET);
	delay_ms(10);
}

/***************************************************************************//**
 * @brief Clears the Reset bit of the AD9833.
 *
 * @return None.
*******************************************************************************/
void AD9833_ClearReset(void)
{
	AD9833_SetRegisterValue_all(AD9833_REG_CMD);
}
/***************************************************************************//**
 * @brief Writes the value to a register.
 *
 * @param -  regValue - The value to write to the register.
 *
 * @return  None.    
*******************************************************************************/
void AD9833_SetRegisterValue(unsigned short regValue)
{
	unsigned char data[5] = {0x03, 0x00, 0x00};	
	
	data[1] = (unsigned char)((regValue & 0xFF00) >> 8);
	data[2] = (unsigned char)((regValue & 0x00FF) >> 0);    
	AD9833_SPI_Write(data,2);
}

void AD9833_SetRegisterValue2(unsigned short regValue)
{
	unsigned char data[5] = {0x03, 0x00, 0x00};	
	
	data[1] = (unsigned char)((regValue & 0xFF00) >> 8);
	data[2] = (unsigned char)((regValue & 0x00FF) >> 0);    
	AD9833_SPI_Write2(data,2);
}

void AD9833_SetRegisterValue3(unsigned short regValue)
{
	unsigned char data[5] = {0x03, 0x00, 0x00};	
	
	data[1] = (unsigned char)((regValue & 0xFF00) >> 8);
	data[2] = (unsigned char)((regValue & 0x00FF) >> 0);    
	AD9833_SPI_Write3(data,2);
}
void AD9833_SetRegisterValue_all(unsigned short regValue)
{
	unsigned char data[5] = {0x03, 0x00, 0x00};	
	
	data[1] = (unsigned char)((regValue & 0xFF00) >> 8);
	data[2] = (unsigned char)((regValue & 0x00FF) >> 0);    
	AD9833_SPI_Write_all(data,2);
}
/***************************************************************************//**
 * @brief Writes to the frequency registers.
 *
 * @param -  reg - Frequence register to be written to.
 * @param -  val - The value to be written.
 *
 * @return  None.    
*******************************************************************************/
void AD9833_SetFrequency(unsigned short reg, float fout)
{
	unsigned short freqHi = reg;
	unsigned short freqLo = reg;
	unsigned long val=RealFreDat*fout;//F�Ĵ�����ֵ
	freqHi |= (val & 0xFFFC000) >> 14 ;
	freqLo |= (val & 0x3FFF);
	
	//��������֮��
	//AD9833_SetRegisterValue(AD9833_B28);//k
	AD9833_SetRegisterValue_all(freqLo);
	AD9833_SetRegisterValue_all(freqHi);
}
/***************************************************************************//**
 * @brief Writes to the phase registers.
 *
 * @param -  reg - Phase register to be written to.
 * @param -  val - The value to be written.
 *
 * @return  None.    
*******************************************************************************/
void AD9833_SetPhase(unsigned short reg, unsigned short val)
{
	unsigned short phase = reg;
	phase |= val;
	AD9833_SetRegisterValue(phase);
}

void AD9833_SetPhase2(unsigned short reg, unsigned short val)
{
	unsigned short phase = reg;
	phase |= val;
	AD9833_SetRegisterValue2(phase);
}

void AD9833_SetPhase3(unsigned short reg, unsigned short val)
{
	unsigned short phase = reg;
	phase |= val;
	AD9833_SetRegisterValue3(phase);
}
/***************************************************************************//**
 * @brief Selects the Frequency,Phase and Waveform type.
 *
 * @param -  freq  - Frequency register used.
 * @param -  phase - Phase register used.
 * @param -  type  - Type of waveform to be output.
 *
 * @return  None.    AD9833_Setup(1000,0,AD9833_OUT_SINUS);
*******************************************************************************/
void AD9833_Setup(unsigned short freq,
				  unsigned short phase,
			 	  unsigned short type)
{
	unsigned short val = 0;
	
	val = freq | phase | type;
	AD9833_SetRegisterValue(val);
}
/***************************************************************************//**
 * @brief Sets the type of waveform to be output.
 *
 * @param -  type - type of waveform to be output.
 *
 * @return  None.    
*******************************************************************************/
void AD9833_SetWave(unsigned short type)
{
	AD9833_SetRegisterValue(type);
}
// // 		if(WaveMode==0) //������ǲ�
// // 		 	AD9833_SetRegisterValue(0x2002); 
// // 		if(WaveMode==1)	//�������
// 			AD9833_SetRegisterValue(0x2028); 
// // 		if(WaveMode==2)	//���������
// // 			AD9833_SetRegisterValue(0x2000); 
// }
//static unsigned int Freq_SFR = 0;//��ǰʹ�õ�Frequency reg��0����1
void AD9833_SetFrequencyQuick(float Freq)//
{
	AD9833_SetRegisterValue_all(0x2000);//AD9833_SetRegisterValue(0x2002); ���ǲ���AD9833_SetRegisterValue(0x2000); ������
	AD9833_SetFrequency(AD9833_REG_FREQ0,Freq);	
}





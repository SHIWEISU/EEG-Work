#ifndef _GY_30_H 
#define _GY_30_H 
#include "stm32f10x.h"
#define ADDR 		0x46
#define POWER_DOWN 	0X00
#define POWER_ON	0X01
#define GY_30_RESET	0x07
#define H_MODE		0X10
#define H_MODE2		0X11
#define L_MODE		0X13

void GY_30_open(void);
void GY_30_read(u8 mode);

u16 get_lx(void);

#endif

#include "iic.h"
#include "GY-30.h"

u16 lxbuf;                         //�������ݻ�����     

void GY_30_open(void)
{
	i2c_Start();
	i2c_SendByte(ADDR);
	i2c_SendByte(POWER_ON);
	i2c_Stop();
}

void GY_30_read(u8 mode)
{
	u8 i;
	i2c_Start();
	i2c_SendByte(ADDR);
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* ������Ӧ�� */
	}
	i2c_SendByte(mode);
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* ������Ӧ�� */
	}
	i2c_Start();
	i2c_SendByte(ADDR+1);
	if (i2c_WaitAck() != 0)
	{
		goto cmd_fail;	/* ������Ӧ�� */
	}
	
	lxbuf=i2c_ReadByte();
	i2c_Ack();
	lxbuf=(lxbuf<<8)+i2c_ReadByte();
	i2c_NAck();
		
	i2c_Stop();
	cmd_fail:
	i2c_Stop();
}

u16 get_lx(void)
{
	return (float)lxbuf/1.2;
}



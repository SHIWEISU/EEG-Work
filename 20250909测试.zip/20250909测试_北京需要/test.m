% 读取CSV文件
data = readtable('Curve_脑电数据解析(250909_103608)_崔国顺.csv'); % 假设CSV文件名为data.csv

% 提取时间列并转换为datetime
time = datetime(data{:,1}, 'InputFormat', 'yy-MM-dd HH:mm:ss.SSS');

% 计算采样频率
time_diff = seconds(diff(time)); % 时间差（秒）
fs = 1 / mean(time_diff); % 采样频率（Hz）
disp(['采样频率 fs = ', num2str(fs), ' Hz']);

% 提取8个通道的数据
channels = data{:,2:9}; % 第2到第9列为通道数据
n_channels = 8; % 通道数
n_samples = size(channels, 1); % 样本数

% 设计陷波滤波器：针对50Hz和100Hz干扰
f_notch1 = 50 / (fs / 2); % 50Hz归一化频率
f_notch2 = 100 / (fs / 2); % 100Hz归一化频率
BW = 2 / (fs / 2); % 归一化带宽，2Hz带宽

% 设计IIR陷波滤波器
[b1, a1] = iirnotch(f_notch1, BW);
[b2, a2] = iirnotch(f_notch2, BW);

% 应用陷波滤波并去基线
filtered_channels = zeros(size(channels));
detrended_channels = zeros(size(channels));
for ch = 1:n_channels
    signal = channels(:, ch);
    % 去均值
    signal = signal - mean(signal);
    % 串联应用50Hz和100Hz陷波滤波器
    signal_f1 = filtfilt(b1, a1, signal);
    filtered_signal = filtfilt(b2, a2, signal_f1);
    filtered_channels(:, ch) = filtered_signal;
    % 去基线（使用多项式拟合，线性趋势）
    detrended_signal = detrend(filtered_signal, 1); % 1表示线性去趋势
    detrended_channels(:, ch) = detrended_signal;
end

% FFT参数（用于频谱分析）
nfft = 2^nextpow2(n_samples); % FFT点数
freq = fs * (0:(nfft/2)) / nfft; % 频率轴

% 计算原始信号、滤波后信号和去基线后信号的FFT
original_fft = zeros(nfft/2 + 1, n_channels);
filtered_fft = zeros(nfft/2 + 1, n_channels);
detrended_fft = zeros(nfft/2 + 1, n_channels);
for ch = 1:n_channels
    % 原始信号FFT
    signal = channels(:, ch) - mean(channels(:, ch));
    fft_result = fft(signal, nfft) / n_samples;
    original_fft(:, ch) = abs(fft_result(1:nfft/2 + 1));
    % 滤波后信号FFT
    filtered_signal = filtered_channels(:, ch);
    fft_result = fft(filtered_signal, nfft) / n_samples;
    filtered_fft(:, ch) = abs(fft_result(1:nfft/2 + 1));
    % 去基线后信号FFT
    detrended_signal = detrended_channels(:, ch);
    fft_result = fft(detrended_signal, nfft) / n_samples;
    detrended_fft(:, ch) = abs(fft_result(1:nfft/2 + 1));
end

% 绘制原始、滤波后和去基线后时域波形
figure('Name', 'Time Domain: Original vs Filtered vs Detrended', 'Position', [100, 100, 1200, 800]);
sample_plot =  n_samples; % 限制绘图样本数
t_plot = (0:sample_plot-1) / fs; % 时间轴
for ch = 1:n_channels
    subplot(4, 2, ch);
    plot(t_plot, channels(1:sample_plot, ch) - mean(channels(1:sample_plot, ch)), 'b-', 'DisplayName', 'Original');
    hold on;
    plot(t_plot, filtered_channels(1:sample_plot, ch), 'r-', 'DisplayName', 'Filtered');
    plot(t_plot, detrended_channels(1:sample_plot, ch), 'g-', 'DisplayName', 'Detrended');
    title(['Channel ', num2str(ch)]);
    xlabel('Time (s)');
    ylabel('Amplitude');
    legend('Location', 'best');
    grid on;
    hold off;
end

% 绘制原始、滤波后和去基线后频谱
figure('Name', 'Frequency Domain: Original vs Filtered vs Detrended', 'Position', [100, 100, 1200, 800]);
for ch = 1:n_channels
    subplot(4, 2, ch);
    plot(freq, original_fft(:, ch), 'b-', 'DisplayName', 'Original');
    hold on;
    plot(freq, filtered_fft(:, ch), 'r-', 'DisplayName', 'Filtered');
    plot(freq, detrended_fft(:, ch), 'g-', 'DisplayName', 'Detrended');
    title(['Channel ', num2str(ch)]);
    xlabel('Frequency (Hz)');
    ylabel('Magnitude');
    legend('Location', 'best');
    grid on;
    xlim([0 150]); % 限制频率范围以突出50Hz和100Hz
    hold off;
end

% % 保存去基线后数据到CSV
% detrended_table = array2table(detrended_channels, 'VariableNames', data.Properties.VariableNames(2:9));
% writetable([table(time), detrended_table], 'detrended_data_苏世伟.csv');
% disp('去基线后数据已保存到 detrended_data_苏世伟.csv');
clc
clear
% 读取去基线后的CSV文件
data = readtable('detrended_data_崔国顺.csv'); % 假设文件名为detrended_data.csv

% 提取时间列并转换为datetime
time = datetime(data{:,1}, 'InputFormat', 'yy-MM-dd HH:mm:ss.SSS');

% 计算时间轴
time_diff = seconds(diff(time)); % 时间差（秒）
fs = 1 / mean(time_diff); % 采样频率（Hz）
t_plot = (0:(size(data, 1)-1)) / fs; % 时间轴（秒）

% 提取8个通道的数据
channels = data{:,2:9}; % 第2到第9列为通道数据
n_channels = 8; % 通道数
n_samples = size(channels, 1); % 样本数

% 定义颜色顺序：赤橙黄绿青蓝紫黑
colors = {'r', [1 0.5 0], 'y', 'g', 'c', 'b', 'm', 'k'}; % MATLAB颜色代码
labels = {'Channel 1', 'Channel 2', 'Channel 3', 'Channel 4', ...
          'Channel 5', 'Channel 6', 'Channel 7', 'Channel 8'};

% % 绘制8通道数据在同一张图
% figure('Name', 'Detrended Channels in One Plot', 'Position', [100, 100, 1200, 400]);
% hold on;
% sample_plot =  n_samples; % 限制绘图样本数
% for ch = 1:n_channels
%     plot(t_plot(1:sample_plot), channels(1:sample_plot, ch), ...
%          'Color', colors{ch}, 'LineWidth', 1, 'DisplayName', labels{ch});
% end
% hold off;

% 计算偏移量以避免曲线重叠
% 使用信号的整体幅度范围来确定偏移
offset = zeros(1, n_channels);
offset_base = 0;
for ch = 1:n_channels
    signal_range = max(channels(:, ch)) - min(channels(:, ch));
    offset(ch) = offset_base;
    offset_base = offset_base + 0.2 * signal_range; % 偏移为信号幅度的2倍
end

% 绘制8通道数据在同一张图，带偏移
figure('Name', 'Detrended EEG Channels (Separated)', 'Position', [100, 100, 1200, 800]);
hold on;
sample_plot = n_samples; % 使用全部样本
for ch = 1:n_channels
    plot(t_plot(1:sample_plot), channels(1:sample_plot, ch) + offset(ch), ...
         'Color', colors{ch}, 'LineWidth', 1, 'DisplayName', labels{ch});
end
hold off;

% 设置图表属性
title('Detrended 8-Channel Data');
xlabel('Time (s)');
ylabel('Amplitude');
legend('Location', 'best');
grid on;


% 定义EEG频段（基于标准参考）
bands = {'Delta', 'Theta', 'Alpha', 'Beta', 'Gamma'};
band_limits = [0.5 4; 4 8; 8 13; 13 30; 30 100]; % [low high] Hz for each band

% 初始化存储每个频段的滤波信号
band_signals = cell(length(bands), n_channels);

% 设计和应用带通滤波器
for band_idx = 1:length(bands)
    low_freq = band_limits(band_idx, 1);
    high_freq = band_limits(band_idx, 2);
    
    % 归一化频率
    low_norm = low_freq / (fs / 2);
    high_norm = high_freq / (fs / 2);
    
    % 设计Butterworth带通滤波器（4阶）
    [b, a] = butter(4, [low_norm high_norm], 'bandpass');
    
    % 应用零相位滤波
    for ch = 1:n_channels
        signal = channels(:, ch);
        filtered_signal = filtfilt(b, a, signal);
        band_signals{band_idx, ch} = filtered_signal;
    end
end

for band_idx = 1:length(bands)
    figure('Name', [bands{band_idx}, ' Band EEG Signals'], 'Position', [100, 100, 1200, 800]);
    
    for ch = 1:n_channels
        subplot(4, 2, ch);
        plot(t_plot, band_signals{band_idx, ch}(1:sample_plot), 'LineWidth', 1);
        title([bands{band_idx}, ' - Channel ', num2str(ch)]);
        xlabel('Time (s)');
        ylabel('Amplitude');
        grid on;
    end
    
    % 整体标题
    sgtitle([bands{band_idx}, ' Band (', num2str(band_limits(band_idx, 1)), '-', num2str(band_limits(band_idx, 2)), ' Hz)']);
end

% 可选：保存每个频段的数据到单独的CSV文件
% for band_idx = 1:length(bands)
%     band_data = cell2mat(band_signals(band_idx, :)); % 8通道数据
%     band_table = array2table(band_data, 'VariableNames', data.Properties.VariableNames(2:9));
%     filename = [lower(bands{band_idx}), '_band_data_张玉昊.csv'];
%     writetable([table(time), band_table], filename);
%     disp(['已保存 ', bands{band_idx}, ' 频段数据到 ', filename]);
% end

disp('EEG频段分离完成。图形已绘制为5个独立的figure，每个对应一个频段。');